#!/bin/bash


echo 'Calling scripts!'

rm -rf logs # toggle this off if you want to keep old logs each time you run new experiments
#script logs.txt

### single dataset

python federated_main_single.py --root DATA/ --dataset-config-file configs/datasets/cifar10.yaml --num-users 10 --factorization promptfl --rank 8 --noise 0 --seed 1 --lr 0.0001 --round 200 --gpu 1 &
python federated_main_single.py --root DATA/ --dataset-config-file configs/datasets/cifar10.yaml --num-users 10 --factorization fedpgp --rank 8 --noise 0 --seed 1 --lr 0.0001 --round 200 --gpu 2
python federated_main_single.py --root DATA/ --dataset-config-file configs/datasets/cifar10.yaml --num-users 10 --factorization fedotp --rank 8 --noise 0 --seed 1 --lr 0.0001 --round 200 --gpu 1 &
python federated_main_single.py --root DATA/ --dataset-config-file configs/datasets/cifar10.yaml --num-users 10 --factorization dpfpl --rank 8 --noise 0 --seed 1 --lr 0.0001 --round 200 --gpu 2
python federated_main_single.py --root DATA/ --dataset-config-file configs/datasets/cifar10.yaml --num-users 10 --factorization dpfpl --rank 8 --noise 0.01 --seed 1 --lr 0.0001 --round 200 --gpu 1 &
python federated_main_single.py --root DATA/ --dataset-config-file configs/datasets/cifar10.yaml --num-users 10 --factorization dpfpl --rank 8 --noise 0.1 --seed 1 --lr 0.0001 --round 200 --gpu 2
python federated_main_single.py --root DATA/ --dataset-config-file configs/datasets/cifar10.yaml --num-users 10 --factorization dpfpl --rank 8 --noise 0.4 --seed 1 --lr 0.0001 --round 200 --gpu 1 &
python federated_main_single.py --root DATA/ --dataset-config-file configs/datasets/cifar10.yaml --num-users 10 --factorization secfpp --rank 8 --noise 0 --seed 1 --lr 0.0001 --round 200 --gpu 2

python federated_main_single.py --root DATA/ --dataset-config-file configs/datasets/caltech101.yaml --num-users 10 --factorization promptfl --rank 8 --noise 0 --seed 1 --lr 0.0001 --round 200 --gpu 1 &
python federated_main_single.py --root DATA/ --dataset-config-file configs/datasets/caltech101.yaml --num-users 10 --factorization fedpgp --rank 8 --noise 0 --seed 1 --lr 0.0001 --round 200 --gpu 2
python federated_main_single.py --root DATA/ --dataset-config-file configs/datasets/caltech101.yaml --num-users 10 --factorization fedotp --rank 8 --noise 0 --seed 1 --lr 0.0001 --round 200 --gpu 2 &
python federated_main_single.py --root DATA/ --dataset-config-file configs/datasets/caltech101.yaml --num-users 10 --factorization dpfpl --rank 8 --noise 0 --seed 1 --lr 0.0001 --round 200 --gpu 1
python federated_main_single.py --root DATA/ --dataset-config-file configs/datasets/caltech101.yaml --num-users 10 --factorization dpfpl --rank 8 --noise 0.01 --seed 1 --lr 0.0001 --round 200 --gpu 2 &
python federated_main_single.py --root DATA/ --dataset-config-file configs/datasets/caltech101.yaml --num-users 10 --factorization dpfpl --rank 8 --noise 0.1 --seed 1 --lr 0.0001 --round 200 --gpu 1
python federated_main_single.py --root DATA/ --dataset-config-file configs/datasets/caltech101.yaml --num-users 10 --factorization dpfpl --rank 8 --noise 0.4 --seed 1 --lr 0.0001 --round 200 --gpu 1 &
python federated_main_single.py --root DATA/ --dataset-config-file configs/datasets/caltech101.yaml --num-users 10 --factorization secfpp --rank 8 --noise 0 --seed 1 --lr 0.0001 --round 200 --gpu 2
#
python federated_main_single.py --root DATA/ --dataset-config-file configs/datasets/oxford_pets.yaml --num-users 10 --factorization promptfl --rank 8 --noise 0 --seed 1 --lr 0.0001 --round 200 --gpu 1 &
python federated_main_single.py --root DATA/ --dataset-config-file configs/datasets/oxford_pets.yaml --num-users 10 --factorization fedpgp --rank 8 --noise 0 --seed 1 --lr 0.0001 --round 200 --gpu 2
python federated_main_single.py --root DATA/ --dataset-config-file configs/datasets/oxford_pets.yaml --num-users 10 --factorization fedotp --rank 8 --noise 0 --seed 1 --lr 0.0001 --round 200 --gpu 1 &
python federated_main_single.py --root DATA/ --dataset-config-file configs/datasets/oxford_pets.yaml --num-users 10 --factorization dpfpl --rank 8 --noise 0 --seed 1 --lr 0.0001 --round 200 --gpu 2
python federated_main_single.py --root DATA/ --dataset-config-file configs/datasets/oxford_pets.yaml --num-users 10 --factorization dpfpl --rank 8 --noise 0.01 --seed 1 --lr 0.0001 --round 200 --gpu 2 &
python federated_main_single.py --root DATA/ --dataset-config-file configs/datasets/oxford_pets.yaml --num-users 10 --factorization dpfpl --rank 8 --noise 0.1 --seed 1 --lr 0.0001 --round 200 --gpu 1
python federated_main_single.py --root DATA/ --dataset-config-file configs/datasets/oxford_pets.yaml --num-users 10 --factorization dpfpl --rank 8 --noise 0.4 --seed 1 --lr 0.0001 --round 200 --gpu 1 &
python federated_main_single.py --root DATA/ --dataset-config-file configs/datasets/oxford_pets.yaml --num-users 10 --factorization secfpp --rank 8 --noise 0 --seed 1 --lr 0.0001 --round 200 --gpu 2

python federated_main_single.py --root DATA/ --dataset-config-file configs/datasets/oxford_flowers.yaml --num-users 10 --factorization promptfl --rank 8 --noise 0 --seed 1 --lr 0.0001 --round 200 --gpu 1 &
python federated_main_single.py --root DATA/ --dataset-config-file configs/datasets/oxford_flowers.yaml --num-users 10 --factorization fedpgp --rank 8 --noise 0 --seed 1 --lr 0.0001 --round 200 --gpu 2
python federated_main_single.py --root DATA/ --dataset-config-file configs/datasets/oxford_flowers.yaml --num-users 10 --factorization fedotp --rank 8 --noise 0 --seed 1 --lr 0.0001 --round 200 --gpu 1 &
python federated_main_single.py --root DATA/ --dataset-config-file configs/datasets/oxford_flowers.yaml --num-users 10 --factorization dpfpl --rank 8 --noise 0 --seed 1 --lr 0.0001 --round 200 --gpu 2
python federated_main_single.py --root DATA/ --dataset-config-file configs/datasets/oxford_flowers.yaml --num-users 10 --factorization dpfpl --rank 8 --noise 0.01 --seed 1 --lr 0.0001 --round 200 --gpu 1 &
python federated_main_single.py --root DATA/ --dataset-config-file configs/datasets/oxford_flowers.yaml --num-users 10 --factorization dpfpl --rank 8 --noise 0.1 --seed 1 --lr 0.0001 --round 200 --gpu 2
python federated_main_single.py --root DATA/ --dataset-config-file configs/datasets/oxford_flowers.yaml --num-users 10 --factorization dpfpl --rank 8 --noise 0.4 --seed 1 --lr 0.0001 --round 200 --gpu 1 &
python federated_main_single.py --root DATA/ --dataset-config-file configs/datasets/oxford_flowers.yaml --num-users 10 --factorization secfpp --rank 8 --noise 0 --seed 1 --lr 0.0001 --round 200 --gpu 2

python federated_main_single.py --root DATA/ --dataset-config-file configs/datasets/dtd.yaml --num-users 10 --factorization promptfl --rank 8 --noise 0 --seed 1 --lr 0.0001 --round 200 --gpu 1 &
python federated_main_single.py --root DATA/ --dataset-config-file configs/datasets/dtd.yaml --num-users 10 --factorization fedpgp --rank 8 --noise 0 --seed 1 --lr 0.0001 --round 200 --gpu 2
python federated_main_single.py --root DATA/ --dataset-config-file configs/datasets/dtd.yaml --num-users 10 --factorization fedotp --rank 8 --noise 0 --seed 1 --lr 0.0001 --round 200 --gpu 2 &
python federated_main_single.py --root DATA/ --dataset-config-file configs/datasets/dtd.yaml --num-users 10 --factorization dpfpl --rank 8 --noise 0 --seed 1 --lr 0.0001 --round 200 --gpu 1
python federated_main_single.py --root DATA/ --dataset-config-file configs/datasets/dtd.yaml --num-users 10 --factorization dpfpl --rank 8 --noise 0.01 --seed 1 --lr 0.0001 --round 200 --gpu 2 &
python federated_main_single.py --root DATA/ --dataset-config-file configs/datasets/dtd.yaml --num-users 10 --factorization dpfpl --rank 8 --noise 0.1 --seed 1 --lr 0.0001 --round 200 --gpu 1
python federated_main_single.py --root DATA/ --dataset-config-file configs/datasets/dtd.yaml --num-users 10 --factorization dpfpl --rank 8 --noise 0.4 --seed 1 --lr 0.0001 --round 200 --gpu 1 &
python federated_main_single.py --root DATA/ --dataset-config-file configs/datasets/dtd.yaml --num-users 10 --factorization secfpp --rank 8 --noise 0 --seed 1 --lr 0.0001 --round 200 --gpu 3

python federated_main_single.py --root DATA/ --dataset-config-file configs/datasets/food101.yaml --num-users 10 --factorization promptfl --rank 8 --noise 0 --seed 1 --lr 0.0001 --round 200 --gpu 1 &
python federated_main_single.py --root DATA/ --dataset-config-file configs/datasets/food101.yaml --num-users 10 --factorization fedpgp --rank 8 --noise 0 --seed 1 --lr 0.0001 --round 200 --gpu 2
python federated_main_single.py --root DATA/ --dataset-config-file configs/datasets/food101.yaml --num-users 10 --factorization fedotp --rank 8 --noise 0 --seed 1 --lr 0.0001 --round 200 --gpu 1 &
python federated_main_single.py --root DATA/ --dataset-config-file configs/datasets/food101.yaml --num-users 10 --factorization dpfpl --rank 8 --noise 0 --seed 1 --lr 0.0001 --round 200 --gpu 2
python federated_main_single.py --root DATA/ --dataset-config-file configs/datasets/food101.yaml --num-users 10 --factorization dpfpl --rank 8 --noise 0.01 --seed 1 --lr 0.0001 --round 200 --gpu 1 &
python federated_main_single.py --root DATA/ --dataset-config-file configs/datasets/food101.yaml --num-users 10 --factorization dpfpl --rank 8 --noise 0.1 --seed 1 --lr 0.0001 --round 200  --gpu 2
python federated_main_single.py --root DATA/ --dataset-config-file configs/datasets/food101.yaml --num-users 10 --factorization dpfpl --rank 8 --noise 0.4 --seed 1 --lr 0.0001 --round 200 --gpu 1 &
python federated_main_single.py --root DATA/ --dataset-config-file configs/datasets/food101.yaml --num-users 10 --factorization secfpp --rank 8 --noise 0 --seed 1 --lr 0.0001  --round 200 --gpu 2


### multi-domain dataset
#
##  caltech101 + oxford_pets
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/caltech101.yaml --dataset-config-file2 configs/datasets/oxford_pets.yaml  --num-users 10 --factorization promptfl --rank 8 --noise 0 --seed 1 --lr 0.0001 --gpu 1 &
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/caltech101.yaml --dataset-config-file2 configs/datasets/oxford_pets.yaml  --num-users 10 --factorization fedpgp --rank 8 --noise 0 --seed 1 --lr 0.0001 --gpu 2
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/caltech101.yaml --dataset-config-file2 configs/datasets/oxford_pets.yaml  --num-users 10 --factorization fedotp --rank 8 --noise 0 --seed 1 --lr 0.0001 --gpu 1 &
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/caltech101.yaml --dataset-config-file2 configs/datasets/oxford_pets.yaml  --num-users 10 --factorization dpfpl --rank 8 --noise 0 --seed 1 --lr 0.0001 --gpu 2
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/caltech101.yaml --dataset-config-file2 configs/datasets/oxford_pets.yaml  --num-users 10 --factorization dpfpl --rank 8 --noise 0.1 --seed 1 --lr 0.0001 --gpu 2 &
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/caltech101.yaml --dataset-config-file2 configs/datasets/oxford_pets.yaml  --num-users 10 --factorization dpfpl --rank 8 --noise 0.01 --seed 1 --lr 0.0001 ---gpu 1
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/caltech101.yaml --dataset-config-file2 configs/datasets/oxford_pets.yaml  --num-users 10 --factorization dpfpl --rank 8 --noise 0.4 --seed 1 --lr 0.0001 --gpu 1 &
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/caltech101.yaml --dataset-config-file2 configs/datasets/oxford_pets.yaml  --num-users 10 --factorization secfpp --rank 8 --noise 0 --seed 1 --lr 0.0001 --gpu 2

#  caltech101 + food101
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/caltech101.yaml --dataset-config-file2 configs/datasets/food101.yaml  --num-users 10 --factorization promptfl --rank 8 --noise 0 --seed 1 --lr 0.0001 --gpu 1 &
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/caltech101.yaml --dataset-config-file2 configs/datasets/food101.yaml  --num-users 10 --factorization fedpgp --rank 8 --noise 0 --seed 1 --lr 0.0001 --gpu 2
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/caltech101.yaml --dataset-config-file2 configs/datasets/food101.yaml  --num-users 10 --factorization fedotp --rank 8 --noise 0 --seed 1 --lr 0.0001 --gpu 1 &
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/caltech101.yaml --dataset-config-file2 configs/datasets/food101.yaml  --num-users 10 --factorization dpfpl --rank 8 --noise 0 --seed 1 --lr 0.0001 --gpu 2
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/caltech101.yaml --dataset-config-file2 configs/datasets/food101.yaml  --num-users 10 --factorization dpfpl --rank 8 --noise 0.1 --seed 1 --lr 0.0001 --gpu 1 &
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/caltech101.yaml --dataset-config-file2 configs/datasets/food101.yaml  --num-users 10 --factorization dpfpl --rank 8 --noise 0.01 --seed 1 --lr 0.0001 --gpu 2
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/caltech101.yaml --dataset-config-file2 configs/datasets/food101.yaml  --num-users 10 --factorization dpfpl --rank 8 --noise 0.4 --seed 1 --lr 0.0001 --gpu 2 &
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/caltech101.yaml --dataset-config-file2 configs/datasets/food101.yaml  --num-users 10 --factorization secfpp --rank 8 --noise 0 --seed 1 --lr 0.0001 --gpu 1

##  oxford_pets + oxford_flowers
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/oxford_pets.yaml --dataset-config-file2 configs/datasets/oxford_flowers.yaml  --num-users 10 --factorization promptfl --rank 8 --noise 0 --seed 1 --lr 0.0001 --gpu 1 &
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/oxford_pets.yaml --dataset-config-file2 configs/datasets/oxford_flowers.yaml  --num-users 10 --factorization fedpgp --rank 8 --noise 0 --seed 1 --lr 0.0001 --gpu 2
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/oxford_pets.yaml --dataset-config-file2 configs/datasets/oxford_flowers.yaml  --num-users 10 --factorization fedotp --rank 8 --noise 0 --seed 1 --lr 0.0001 --gpu 1 &
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/oxford_pets.yaml --dataset-config-file2 configs/datasets/oxford_flowers.yaml  --num-users 10 --factorization dpfpl --rank 8 --noise 0 --seed 1 --lr 0.0001 --gpu 2
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/oxford_pets.yaml --dataset-config-file2 configs/datasets/oxford_flowers.yaml  --num-users 10 --factorization dpfpl --rank 8 --noise 0.1 --seed 1 --lr 0.0001 --gpu 1 &
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/oxford_pets.yaml --dataset-config-file2 configs/datasets/oxford_flowers.yaml  --num-users 10 --factorization dpfpl --rank 8 --noise 0.01 --seed 1 --lr 0.0001 --gpu 2
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/oxford_pets.yaml --dataset-config-file2 configs/datasets/oxford_flowers.yaml  --num-users 10 --factorization dpfpl --rank 8 --noise 0.4 --seed 1 --lr 0.0001 --gpu 2 &
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/oxford_pets.yaml --dataset-config-file2 configs/datasets/oxford_flowers.yaml  --num-users 10 --factorization secfpp --rank 8 --noise 0 --seed 1 --lr 0.0001 --gpu 1
#
##  dtd + food101
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/dtd.yaml --dataset-config-file2 configs/datasets/food101.yaml  --num-users 10 --factorization promptfl --rank 8 --noise 0 --seed 1 --lr 0.0001 --gpu 1 &
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/dtd.yaml --dataset-config-file2 configs/datasets/food101.yaml  --num-users 10 --factorization fedpgp --rank 8 --noise 0 --seed 1 --lr 0.0001 --gpu 2
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/dtd.yaml --dataset-config-file2 configs/datasets/food101.yaml  --num-users 10 --factorization fedotp --rank 8 --noise 0 --seed 1 --lr 0.0001 --gpu 1 &
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/dtd.yaml --dataset-config-file2 configs/datasets/food101.yaml  --num-users 10 --factorization dpfpl --rank 8 --noise 0 --seed 1 --lr 0.0001 --gpu 2
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/dtd.yaml --dataset-config-file2 configs/datasets/food101.yaml  --num-users 10 --factorization dpfpl --rank 8 --noise 0.1 --seed 1 --lr 0.0001 --gpu 1 &
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/dtd.yaml --dataset-config-file2 configs/datasets/food101.yaml  --num-users 10 --factorization dpfpl --rank 8 --noise 0.01 --seed 1 --lr 0.0001 --gpu 2
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/dtd.yaml --dataset-config-file2 configs/datasets/food101.yaml  --num-users 10 --factorization dpfpl --rank 8 --noise 0.4 --seed 1 --lr 0.0001 --gpu 2 &
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/dtd.yaml --dataset-config-file2 configs/datasets/food101.yaml  --num-users 10 --factorization secfpp --rank 8 --noise 0 --seed 1 --lr 0.0001 --gpu 1
##
##  caltech101 + dtd
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/caltech101.yaml --dataset-config-file2 configs/datasets/dtd.yaml  --num-users 10 --factorization promptfl --rank 8 --noise 0 --seed 1 --lr 0.0001 --gpu 1 &
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/caltech101.yaml --dataset-config-file2 configs/datasets/dtd.yaml  --num-users 10 --factorization fedpgp --rank 8 --noise 0 --seed 1 --lr 0.0001 --gpu 2
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/caltech101.yaml --dataset-config-file2 configs/datasets/dtd.yaml  --num-users 10 --factorization fedotp --rank 8 --noise 0 --seed 1 --lr 0.0001 --gpu 1 &
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/caltech101.yaml --dataset-config-file2 configs/datasets/dtd.yaml  --num-users 10 --factorization dpfpl --rank 8 --noise 0 --seed 1 --lr 0.0001 --gpu 2
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/caltech101.yaml --dataset-config-file2 configs/datasets/dtd.yaml  --num-users 10 --factorization dpfpl --rank 8 --noise 0.1 --seed 1 --lr 0.0001 --gpu 1 &
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/caltech101.yaml --dataset-config-file2 configs/datasets/dtd.yaml  --num-users 10 --factorization dpfpl --rank 8 --noise 0.01 --seed 1 --lr 0.0001 --gpu 2
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/caltech101.yaml --dataset-config-file2 configs/datasets/dtd.yaml  --num-users 10 --factorization dpfpl --rank 8 --noise 0.4 --seed 1 --lr 0.0001 --gpu 2 &
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/caltech101.yaml --dataset-config-file2 configs/datasets/dtd.yaml  --num-users 10 --factorization secfpp --rank 8 --noise 0 --seed 1 --lr 0.0001 --gpu 1

#  cifar10 + caltech101
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/cifar10.yaml --dataset-config-file2 configs/datasets/caltech101.yaml  --num-users 10 --factorization promptfl --rank 8 --noise 0 --seed 1 --lr 0.0001 --gpu 1 &
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/cifar10.yaml --dataset-config-file2 configs/datasets/caltech101.yaml  --num-users 10 --factorization fedpgp --rank 8 --noise 0 --seed 1 --lr 0.0001 --gpu 2
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/cifar10.yaml --dataset-config-file2 configs/datasets/caltech101.yaml  --num-users 10 --factorization fedotp --rank 8 --noise 0 --seed 1 --lr 0.0001 --gpu 1 &
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/cifar10.yaml --dataset-config-file2 configs/datasets/caltech101.yaml  --num-users 10 --factorization dpfpl --rank 8 --noise 0 --seed 1 --lr 0.0001 --gpu 2
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/cifar10.yaml --dataset-config-file2 configs/datasets/caltech101.yaml  --num-users 10 --factorization dpfpl --rank 8 --noise 0.1 --seed 1 --lr 0.0001 --gpu 1 &
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/cifar10.yaml --dataset-config-file2 configs/datasets/caltech101.yaml  --num-users 10 --factorization dpfpl --rank 8 --noise 0.01 --seed 1 --lr 0.0001 --gpu 2 &
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/cifar10.yaml --dataset-config-file2 configs/datasets/caltech101.yaml  --num-users 10 --factorization dpfpl --rank 8 --noise 0.4 --seed 1 --lr 0.0001 --gpu 1
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/cifar10.yaml --dataset-config-file2 configs/datasets/caltech101.yaml  --num-users 10 --factorization secfpp --rank 8 --noise 0 --seed 1 --lr 0.0001 --gpu 2 &

#  cifar100 + caltech101
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/cifar100.yaml --dataset-config-file2 configs/datasets/caltech101.yaml  --num-users 10 --factorization promptfl --rank 8 --noise 0 --seed 1 --lr 0.0001 --gpu 1 &
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/cifar100.yaml --dataset-config-file2 configs/datasets/caltech101.yaml  --num-users 10 --factorization fedpgp --rank 8 --noise 0 --seed 1 --lr 0.0001 --gpu 2
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/cifar100.yaml --dataset-config-file2 configs/datasets/caltech101.yaml  --num-users 10 --factorization fedotp --rank 8 --noise 0 --seed 1 --lr 0.0001 --gpu 1 &
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/cifar100.yaml --dataset-config-file2 configs/datasets/caltech101.yaml  --num-users 10 --factorization dpfpl --rank 8 --noise 0 --seed 1 --lr 0.0001 --gpu 2
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/cifar100.yaml --dataset-config-file2 configs/datasets/caltech101.yaml  --num-users 10 --factorization dpfpl --rank 8 --noise 0.1 --seed 1 --lr 0.0001 --gpu 1
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/cifar100.yaml --dataset-config-file2 configs/datasets/caltech101.yaml  --num-users 10 --factorization dpfpl --rank 8 --noise 0.01 --seed 1 --lr 0.0001 --gpu 2 &
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/cifar100.yaml --dataset-config-file2 configs/datasets/caltech101.yaml  --num-users 10 --factorization dpfpl --rank 8 --noise 0.4 --seed 1 --lr 0.0001 --gpu 1
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/cifar100.yaml --dataset-config-file2 configs/datasets/caltech101.yaml  --num-users 10 --factorization secfpp --rank 8 --noise 0 --seed 1 --lr 0.0001 --gpu 2 &

#  caltech101 + oxford_flowers
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/caltech101.yaml --dataset-config-file2 configs/datasets/oxford_flowers.yaml  --num-users 10 --factorization promptfl --rank 8 --noise 0 --seed 1 --lr 0.0001 --gpu 1 &
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/caltech101.yaml --dataset-config-file2 configs/datasets/oxford_flowers.yaml  --num-users 10 --factorization fedpgp --rank 8 --noise 0 --seed 1 --lr 0.0001 --gpu 2
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/caltech101.yaml --dataset-config-file2 configs/datasets/oxford_flowers.yaml  --num-users 10 --factorization fedotp --rank 8 --noise 0 --seed 1 --lr 0.0001 --gpu 1 &
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/caltech101.yaml --dataset-config-file2 configs/datasets/oxford_flowers.yaml  --num-users 10 --factorization dpfpl --rank 8 --noise 0 --seed 1 --lr 0.0001 --gpu 2
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/caltech101.yaml --dataset-config-file2 configs/datasets/oxford_flowers.yaml  --num-users 10 --factorization dpfpl --rank 8 --noise 0.1 --seed 1 --lr 0.0001 --gpu 1 &
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/caltech101.yaml --dataset-config-file2 configs/datasets/oxford_flowers.yaml  --num-users 10 --factorization dpfpl --rank 8 --noise 0.01 --seed 1 --lr 0.0001 --gpu 1
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/caltech101.yaml --dataset-config-file2 configs/datasets/oxford_flowers.yaml  --num-users 10 --factorization dpfpl --rank 8 --noise 0.4 --seed 1 --lr 0.0001 --gpu 2 &
#python federated_main_multidomain.py --root DATA/ --dataset-config-file configs/datasets/caltech101.yaml --dataset-config-file2 configs/datasets/oxford_flowers.yaml  --num-users 10 --factorization secfpp --rank 8 --noise 0 --seed 1 --lr 0.0001 --gpu 1


echo 'All experiments are finished!'