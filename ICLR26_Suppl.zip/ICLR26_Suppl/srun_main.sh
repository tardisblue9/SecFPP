#!/bin/bash

python federated_main.py --root $1 --dataset-config-file $2 --num-users $3 --rank $4 --noise $5 --seed $6
